<template>
	<SharedPagesStatistics></SharedPagesStatistics>
</template>
